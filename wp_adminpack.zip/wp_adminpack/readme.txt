=== WP Admin Pack ===
Tested up to: 3.4.2
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Wordpress Dashboard functionality addons.

== Installation ==

1. Unpack posts_auto_filter.zip to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Description ==

Add General Functionality in Dashboard:

   1. Hide / Unhide Update Messages on Dashboard
   2. Posts / Pages Editor (/wp-admin/edit.php)
      2.1 Auto refresh posts listing when specific
          category or dates are selected.
   3. Theme Editor Functionality (wp-admin/theme-editor.php)
      3.1 Add Ctrl+S shortcut for updating files.
      3.2 Auto refresh page when different theme is selected. (No need to select theme and click 'Select')